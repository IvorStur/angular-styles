import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-one',
  templateUrl: './one.component.html',
  styleUrls: ['./one.component.css'],
})
export class OneComponent implements OnInit {
  bool: boolean = false;
  farba: string;
  styles: any = {
    'background-color': this.bool ? 'purple' : 'green'
    // 'border': this.bool ? 'solid 2px' : 'none'

  }
  constructor() {}

  ngOnInit() {}

  farba_func(): void {
    if (this.bool == false) {
      this.farba = 'green';
    } else {
      this.farba = 'purple';
    }
  }

  zmenBool(): void {
    this.bool = !this.bool;
    this.styles =  {
      'background-color': this.bool ? 'purple' : 'green'
      // 'border': this.bool ? 'solid 2px' : 'none' 
    }
  }
}
